# Personality Backend

This is a simple backend deployed on **Vercel** for personality questions & analysis.

## API Endpoints
- `/api/hello`
- `/api/questions-by-age?age=20`
- `/api/analyze-answers`
